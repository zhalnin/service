<?php
/**
 * Created by JetBrains PhpStorm.
 * User: zhalnin
 * Date: 09.12.12
 * Time: 12:57
 * To change this template use File | Settings | File Templates.
 */
 error_reporting(E_ALL & ~E_NOTICE);
//require "class.Database.php";
/**
 * Defines database connection data.
 */
//define('DB_HOST', 'localhost');
//define('DB_USER', 'root');
//define('DB_PASSWORD', 'root');
//define('DB_DATABASE', 'forum');

//    $db = Database::getInstance();
//    $mysql = $db->getConnection();
?>