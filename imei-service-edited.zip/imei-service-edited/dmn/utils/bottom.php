<?php
/**
 * Created by JetBrains PhpStorm.
 * User: zhalnin
 * Date: 09.12.12
 * Time: 22:21
 * To change this template use File | Settings | File Templates.
 */
 error_reporting(E_ALL & ~E_NOTICE);
/**
 * Form bottom of administration.
 */
?>


  <br/><br/></td><td width=10%>&nbsp;</td></tr>
<tr class=authors>
  <td colspan="3">
      CMS выполнена и поддерживается "alezhal-studio"
     <a href="#">alezhal</a></td></tr>
</table>
</body>
</html>
<script language='JavaScript1.1' type='text/javascript'>
<!--
  function delete_position(url, ask)
  {
    if(confirm(ask))
    {
      location.href=url;
    }
    return false;
  }
//-->
</script>