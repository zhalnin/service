<?php
/**
 * Created by JetBrains PhpStorm.
 * User: zhalnin
 * Date: 25.03.12
 * Time: 21:33
 * To change this template use File | Settings | File Templates.
 */
  header("Location: system_accounts/index.php");
?>
