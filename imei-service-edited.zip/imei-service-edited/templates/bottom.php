<?php
/**
 * Created by JetBrains PhpStorm.
 * User: zhalnin
 * Date: 22.12.12
 * Time: 15:08
 * To change this template use File | Settings | File Templates.
 */
 error_reporting(E_ALL & ~E_NOTICE);
?>



<div id="footer">
    <div id="footer-content">
        <ol id="breadcrumbs">
            <li>
                <p>Designed by alezhal-studio</p>
            </li>
            <li>
                |
            </li>
            <li>
                <p>Copyright © 2013 All rights reserved.</p>
            </li>
        </ol>
    </div>
</div><!-- footer-->






</body>
</html>
