<?php
/**
 * Created by PhpStorm.
 * User: zhalnin
 * Date: 15/06/14
 * Time: 14:41
 */


namespace imei_service\view;
error_reporting( E_ALL & ~E_NOTICE );
//require_once( "imei_service/view/ViewHelper.php" );
//
//$request = \imei_service\view\VH::getRequest();
//
//print "sendMail - view";
?>